package com.horizon.ecommerceproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
